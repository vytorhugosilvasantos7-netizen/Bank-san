// Bank-San | Conexão com o Supabase
// Antes deste arquivo, a página precisa carregar a biblioteca:
//   <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
//
// Cole aqui a URL do projeto e a chave PUBLISHABLE (começa com sb_publishable_).
// Essa chave pode ficar no site: quem protege os dados são as regras do schema.sql.
// NUNCA cole aqui a chave "secret" (sb_secret_...) nem a "service_role".
const SUPABASE_URL = 'https://SEU-PROJETO.supabase.co';
const SUPABASE_KEY = 'sb_publishable_COLE_AQUI';

window.bankSanDb = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
